#include "set.h"


 void read_set (Set *A, int num[])
 {
      int mask;
      int i = 0;
      while (num[i] != -1)
      {
          mask = 1 << (num[i] % CHAR_BITS);
          A->members[num[i]/CHAR_BITS] |= mask;
          i++;
      }

 }

 void union_set(Set *A, Set *B, Set *C)
 {
    int i;
    for (i = 0; i < CHAR_SIZE; i++)
    {
        C->members[i] = A->members[i] | B->members[i];
    }
 }

 void intersect_set (Set *A, Set *B, Set *C)
 {
     int i;
     for (i = 0; i < CHAR_SIZE; i++)
     {
         C->members[i] = A->members[i] & B->members[i];
     }
 }


 void sub_set (Set *A, Set *B, Set *C)
 {
     int i = 0;
     for (i=0;i<CHAR_SIZE;i++)
     {
         C->members[i] = A->members[i] & ~(B->members[i]);
     }

 }


 void stop()
 {
    exit(0);
 }

 void print_set(Set *A, char *name)
 {
     int temp, flag = 0;
     unsigned int mask = 1;
     int i;
     for(i=0;i<CHAR_SIZE;i++)
     {
         if (A->members[i] != 0)
             flag = 1;
     }
     if (flag == 0)
     {
         printf("\nThe set is empty\n");
         return;
     }
     i = 0;
     printf("\nThe set members of %s are:\n",name);
     while (i < GROUP_SIZE)
     {
         mask = 1 << (i % CHAR_BITS);
         temp = A->members[i/CHAR_BITS] & mask;
         if (temp != 0)
             printf("%d\n",i);
         i++;
     }
 }