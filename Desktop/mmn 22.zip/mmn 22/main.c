#include "set.h"

#define MAX_LEN_CM 14
#define MAX_INPUT 80
#define PARAM_NAME 4
#define PARAM_NUM 6
#define MAX_NUMS 80
#define NUM_OF_PARAM 3
#define STOP_LEN 4


struct {
    char *name;
    void (*func)(char[]);
} cmd[] = {
        {"read_set", readIn},
        {"union_set", unionIn},
        {"print_set", printIn},
        {"intersect_set", intersectIn},
        {"sub_set", subIn},
        {"stop", stopIn},
        {"not valid", NULL}
};

struct {
    char *name; /* +1 for '/0' */
    Set group;
} parameter[] = {
        {"SETA", {{0}}},
        {"SETB", {{0}}},
        {"SETC", {{0}}},
        {"SETD", {{0}}},
        {"SETE", {{0}}},
        {"SETF", {{0}}}
};

int getLine(char *, int);
int findComma (char *);
int getNum(char *, int[], int);
int findParam (char *);
int findExtra (char *);

int main()
{
    char s[MAX_INPUT];
    int i, cmdlen, funcI, len, f;
    for(;;)
    {
        i=0;
        len = getLine(s,MAX_INPUT);
        if(len == 0)   /* gets a new line and checks if it empty */
            continue;
        printf("\nThe command you entered: %s\n", s);
        if (len == -2) /* exceeded the limit */
        {
            printf("Error! The line you entered is too long. The limit is %d chars.\n", MAX_INPUT-1);
            continue;
        }
        if (len == -1) /* no newline (found EOF) */
        {
            while (i<len && isspace(s[i])) /* skip blanks */
                i++;
            if ((strncmp(s,"stop", STOP_LEN) == 0) && findExtra(&s[i+ STOP_LEN])) /* check if 'stop' command detected */
                stop();
            else
            {
                printf("Error! EOF. 'stop' command is missing\n");
                exit(1);
            }
        }
        while (i<len && isspace(s[i])) /* skip blanks */
            i++;
        for (funcI = 0; cmd[funcI].func!=NULL;funcI++)
        {
            cmdlen = strlen(cmd[funcI].name);
            if (strncmp(&s[i],cmd[funcI].name, cmdlen) == 0)
                break;
        }
        if (cmd[funcI].func == NULL)
            printf("Error! Undefined command name\n");
        else
        {
            i+=cmdlen;
            if ((i < (len) && !isspace(s[i])))
            {
                if (s[i] == ',')
                    printf("Error! Illegal comma\n");
                else
                    printf("Error! Undefined command name\n");
            }
            else if (i > len)
                printf("Error! Missing parameter\n");
            (*(cmd[funcI].func))(&s[i]);
        }

    }
}

void readIn(char *s)
{
    int i = 0, len, temp, paramIndex, i2 = 0, cmp;
    int nums[MAX_NUMS];
    len = strlen(s);
    while (i<len && isspace(*(s+i))) /* skip blanks */
        i++;
    if (i< len && s[i] == ',') /* check illegal comma before set name */
    {
        printf("Error! Illegal comma\n");
        return;
    }
    if ((paramIndex = findParam(&s[i])) < 0) /* missing parameter */
    {
        return;
    }
    i += PARAM_NAME;
    if (i < len && !(isspace(s[i]) || s[i] == ',' || s[i] == '\0')) /* Wrong parameter name */
    {
        printf("Error! Undefined set name\n");
        return;
    }
    if (i >= len)
    {
        printf("Error! List of set members is missing\n");
        return;
    }
    do
    {
        if ((temp = findComma(&s[i])) < 0)  /* didn't found a comma */
        {
            printf("Error! Missing comma\n");
            return;
        }
        i += temp;      /* skip the checked indexes */
        if (findComma(&s[++i]) >= 0) /* found second comma */
        {
            printf("Error! Multitiple consecutive commas\n");
            return;
        }
        if ((temp = getNum(&s[i], &nums, i2)) == EOF)
        {
            printf("Error! List of set members is not terminated correctly\n");
            return;
        }
        if (temp == -1) /* not an integer */
        {
            printf("Error! Invalid set number - not an integer\n");
            return;
        }
        if (temp == -2) /* out of range */
        {
            printf("Error! Invalid set number - out of range\n");
            return;
        }
        i += temp;
        i2++;
    } while(i2 < MAX_NUMS && nums[i2-1] != -1);
    if (i2 == MAX_NUMS)
    {
        printf("Error! Too many set members\n");
        return;
    }
    if (findExtra(&s[i]) < 0)    /* found a char after the end of command */
    {
        printf("Error! Extraneous text after end of command\n");
        return;
    }
    read_set(&(parameter[paramIndex].group) ,nums);
}

void printIn (char *s) {
    int i = 0, len, paramIndex;
    len = strlen(s);
    while (s[i] != '\0' && isspace(*(s+i))) /* skip blanks */
        i++;
    if (i< len && s[i] == ',') /* check illegal comma before set name */
    {
        printf("Error! Illegal comma\n");
        return;
    }
    if ((paramIndex = findParam(&s[i])) < 0) /* missing parameter */
    {
        return;
    }
    i += PARAM_NAME;
    if (i < len && !(isspace(s[i]) || s[i] == ',' || s[i] == '\0'))
    {
        printf("Error! Undefined set name\n");
        return;
    }
    if (findExtra(&s[i]) < 0)    /* found a char after the end of command */
    {
        printf("Error! Extraneous text after end of command\n");
        return;
    }
    print_set(&(parameter[paramIndex].group),parameter[paramIndex].name);
}
void subIn (char s[])
{
    runSubInterUnion(s,sub_set);
}

void unionIn (char s[])
{
    runSubInterUnion(s,union_set);
}

void intersectIn (char s[])
{
    runSubInterUnion(s,intersect_set);
}

void stopIn (char s[])
{
    if (findExtra(s) < 0)
    {
        printf("Error! Extraneous text after end of command");
        return;
    }
    stop();
}

void runSubInterUnion (char *s, void (*func)(Set *,Set *, Set *))
{
    int i = 0, len, temp, paramI[NUM_OF_PARAM], i2 = 0, index;
    len = strlen(s);
    while (i<len && isspace(*(s+i))) /* skip blanks */
        i++;
    if (i< len && s[i] == ',') /* check illegal comma before set name */
    {
        printf("Error! Illegal comma\n");
        return;
    }
    for (index = 0; index < NUM_OF_PARAM;index++)
    {
        if ((paramI[index] = findParam(&s[i])) < 0) /* missing parameter */
            return;
        i+=PARAM_NAME;
        if (index < (NUM_OF_PARAM - 1))
        {
            if ((temp = findComma(&s[i])) < 0)  /* didn't found a comma */
            {
                printf("Error! Missing comma\n");
                return;
            }
            i += temp;      /* skip the checked indexes */
            if (findComma(&s[++i]) >= 0) /* found second comma */
            {
                printf("Error! Multitiple consecutive commas\n");
                return;
            }
        }
    }
    if (findExtra(&s[i]) < 0)
    {
        printf("Error! Extraneous text after end of command");
        return;
    }
    (*(func))(&(parameter[paramI[0]].group),&(parameter[paramI[1]].group),&(parameter[paramI[2]].group));
}

int findExtra (char *s)
{
    int i = 0;
    while (s[i] != '\0') /* check extraneous text */
    {
        if (!isspace(s[i]))    /* found a char after the end of command */
            return -1;
        i++;
    }
    return i;
}



/*
 * The func find in the array if the first chars are a parameter's name and return
 * the index of the parameter in parameter[];
 * Else, it will print the right error and return -1.
 */
int findParam (char *s)
{
    int i = 0, paramIndex;
    for (paramIndex = 0; paramIndex < PARAM_NUM;paramIndex++)
    {
        if (strncmp(s+i, parameter[paramIndex].name, PARAM_NAME) == 0)
            break;
    }
    i += PARAM_NAME;
    if (paramIndex == PARAM_NUM)
    {
        printf("Error! Undefined set name\n");
        return -1;
    }
    return paramIndex;
}

/*
 * The func get a new line from the stdin. The line is limited by (cnt-1) chars.
 * Returns the len of the new line. If there is no newline char from the stdin (EOF), returns -1.
 * Returns -2 if the the input chars are exceeded the limit (more than cnt-1).
 */
int getLine(char s[], int cnt)
{
     int len, i = 0;
     char *test;
     test = fgets(s,cnt,stdin);
     if (test == NULL)
         return -1;
     len = strlen(s);
         if (len == cnt && s[len-1] != '\n')
             return -2; /* the input chars are exceeded the limit (cnt-1) */
     s[len-1] = '\0'; /* delete the newline  */
     return (len-1); /* return the len of s  */
}

int findComma (char *s)
{
    int i = 0, len;
    len = strlen(s);
    while (i < len && isspace(s[i]))
        i++;
    if (i == len)
        return -2;
    if (s[i]!=',')
        return -1;
    else
        return i;


}

int getNum(char *s, int nums[], int index)
{
    int i, len, temp=0, start = 0, sign = 1;
    len = strlen(s);
    while (start < len && isspace(s[start]))
        start++;
    if (s[start] == '-')
    {
        sign = -1;
        start++;
    }
    i = start;
    while (i < len && isdigit(s[i]))
    {
        temp *= 10;
        temp += (s[i] - '0');
        i++;
    }
    temp *= sign;
    if (start == i || !(isspace(s[i]) || s[i] == ',' || s[i] == '\0'))
        return -1;
    if (i == len && temp != -1)
        return EOF;
    if (temp < -1 || temp >= GROUP_SIZE)
        return -2;
    nums[index] = temp;
    return i;
}
